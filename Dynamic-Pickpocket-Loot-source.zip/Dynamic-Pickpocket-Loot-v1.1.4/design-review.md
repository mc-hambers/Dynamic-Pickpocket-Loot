# Dynamic Pickpocket Loot — review worksheet

Status: approved design baseline, incorporating the latest user decisions. Not implemented or runtime-verified. Actual record mappings and engine hooks still require inspection.

## Confirmed scope

- Skyrim SE and AE in one distribution and, where supported by the selected library and hooks, one DLL. No SPID dependency; see the integration assessment below. Exact Steam/GOG runtime coverage must be established and tested before release. SKSE must match the player's runtime.
- No in-game player configuration. The finalized values are shipped defaults.
- No personal notes, bounty notices, keys, or quest integration. Personal notes and bounties are deferred to the notes expansion.
- Ordinary generated items remain available as corpse loot. Never generate for a dead actor's first encounter.
- Existing eligible saves activate on load: initialize loaded eligible actors, then newly encountered actors. No synchronous whole-world scan.
- Only add shortfalls. Never remove existing possessions to enforce budgets.
- Once per actual inventory-reset cycle. Full and partial resets must be inspected separately to avoid duplicating categories the engine did not clear. Updating must not be treated as a reset. Uninstall/reinstall persistence is outside scope.
- Every eligible actor has at least one qualifying pocket possession after generation. If otherwise empty, bring their coin count to a fallback target of 2–4 coins (children 2–4; prisoners 2–3), without exceeding their profile's gold ceiling. Theft can subsequently empty pockets; this guarantee is checked only during genuine generation, not continuously.
- Confirmed during implementation: valuables budgets are strict, with no rare over-budget exception. Some low-wealth NPCs therefore cannot receive vanilla gems or jewelry whose cheapest item exceeds their budget, even when that category roll succeeds.

## Loot balance worksheet

Edit the proposed values in this table. Gold floor is a generation target floor, not money automatically replaced after theft. Category chances are independent starting values; item-count and value caps override successful rolls.

| Wealth | Target gold range | Gold floor after valuables offset | Coins-only roll chance | Max generated non-gold stacks | Total valuables target budget | Max generated valuables |
|---|---|---|---|---|---|---|
| Destitute | 0–4 | 0 | 50% | 1 | 0–10 | 1 |
| Poor | 2–15 | 0 | 25% | 2 | 5–30 | 1 |
| Common | 8–35 | 2 | 10% | 3 | 15–75 | 2 |
| Comfortable | 20–65 | 5 | 3% | 3 | 40–150 | 2 |
| Wealthy | 40–120 | 10 | 1% | 4 | 100–350 | 3 |
| Noble | 60–180 | 20 | 0% | 4 | 200–600 | 3 |

The former empty-pocket roll now produces a coins-only target: skip non-gold generation and ensure a few coins within the profile gold ceiling, counting existing coins. It never removes existing items. Ammunition is outside this mod and does not satisfy the pocket-possession guarantee. On every other roll, existing qualifying coins or pocket items, including worn jewelry, satisfy the guarantee; if still empty after generation, apply the coin fallback. This also applies to children and prisoners. Weapons and outfits alone do not satisfy it.

| Wealth | Food/drink | Jewelry/trinket | Gem | Potion | Ingredient | Scroll/soul gem | Lockpick |
|---|---|---|---|---|---|---|---|
| Destitute | 20% | 4% | 1% | 1% | 5% | 1% | 3% |
| Poor | 30% | 12% | 3% | 5% | 10% | 2% | 6% |
| Common | 40% | 25% | 8% | 12% | 15% | 6% | 10% |
| Comfortable | 45% | 40% | 15% | 20% | 20% | 12% | 12% |
| Wealthy | 50% | 60% | 30% | 30% | 25% | 20% | 15% |
| Noble | 55% | 75% | 45% | 35% | 30% | 25% | 15% |

Additional fields to edit:

| Setting | Proposed default |
|---|---|
| Lower-value roll preference | Favor lower/middle values; uniform versus weighted roll still to choose |
| Food/drink target stack count | 1–2, usually one item per stack |
| Ingredient target quantity | 1–3 units total |
| Potion target quantity | 1 |
| Scroll/soul gem target quantity | 1 |
| Lockpick target quantity | 1–3 |
| Existing valuables-to-gold offset | 25% of qualifying existing base value, rounded down |
| Gold offset value basis | Vanilla form base value, not merchant sale price |
| Enchanted jewelry generation | Disabled initially; existing enchanted jewelry still counts |
| Children gold target/floor | 0–5 / 0 |
| Children coins-only chance/max stacks | 35% / 1 |
| Children pools | Food, flowers, low-value trinkets; no alcohol, potions, scrolls, soul gems, or lockpicks |
| Prisoners gold target/floor | 0–3 / 0 |
| Prisoners coins-only chance/max stacks | 70% / 1 |
| Prisoners pools | Bread or a cheap personal trinket; no gems, potions, magical supplies, alcohol, or lockpicks |
| Existing above-cap inventories | Preserve them; add nothing to satisfied categories |

The child/prisoner pool restrictions are proposed explicit exceptions to the shared adult pools. Nonzero adult category chances remain possible for every adult occupation.

## Existing-item accounting

1. Snapshot the actor's current inventory before adding anything. Count worn jewelry, existing gold, and qualifying items from vanilla and other mods.
2. Roll category target counts and the total valuables target budget. Existing valuables reduce that budget and satisfy the count targets; do not budget each category independently in a way that stacks rings and gems.
3. Proposed gold calculation: adjustedGoldTarget = max(profileGoldFloor, rolledGoldTarget - floor(existingQualifyingValuablesBaseValue * 0.25)); goldToAdd = max(0, adjustedGoldTarget - existingGold).
4. Use only pre-generation existing valuables for that offset. Generated jewelry does not change the gold calculation midway through a generation.
5. For every other category, add only max(0, targetQuantity - currentQualifyingQuantity), also respecting the combined stack and valuables budgets. Never force an item whose value exceeds the remaining budget.
6. Weapons, armor other than jewelry, quest items, and bulky trade goods do not reduce pocket-gold targets. Proposed: count all carried jewelry and gems, including stolen/player-given items; exclude quest-protected items from budget accounting.
7. These are generation decisions, not continuous minimums. Theft never causes a pocket refill.
8. Final post-generation guarantee: if there is no qualifying pocket possession, add only the shortfall to the saved fallback coin target. For coins-only rolls, ensure that coin target even if a non-gold possession already exists. Never reroll or top up this target outside an authorized generation cycle.

Implementation clarification (v0.1.2): only recognized rings/necklaces occupying jewelry slots and Misc-form gemstones count toward the gold offset. Clothing, armor, weapons, junk, and supplies never contribute to that value, regardless of their price. A full-body outfit with a stray jewelry keyword is excluded.

## Vanilla item pool proposal

All entries below are candidate item families; exact records, names, values, and weights will be checked against Skyrim.esm before building. No dependency on paid Creation Club content. Mod-added equivalent possessions count for accounting but are not generated by default.

| Category | Proposed vanilla contents | Limits |
|---|---|---|
| Food | Bread, apple, carrot, potato, cheese wedge, cooked beef, cooked venison, cooked salmon | Small portions only; no whole cheese wheels or heavy raw carcasses |
| Drink | Ale, mead, wine; higher wealth favors more valuable vanilla wine/mead variants | One bottle; no skooma by default |
| Jewelry | Unenchanted silver/gold rings and necklaces, including vanilla jeweled variants | Budget determines quality; worn jewelry counts |
| Small trinkets | Low-value rings and necklaces from the jewelry pool | No separate junk roll that duplicates jewelry; custom trinkets deferred |
| Gems | Garnet, amethyst, ruby, sapphire, emerald, diamond, and their flawless variants | Cheap gems weighted more heavily; expensive ones require budget |
| Potions | Restore Health, Restore Magicka, Restore Stamina families at suitable vanilla strengths | No poison or rare high-value elixir by default |
| Ingredients | Blue/red/purple mountain flower, lavender, tundra cotton, thistle branch, salt pile, garlic, snowberries, frost mirriam, elves ear, bone meal | Exclude quest ingredients and rare human remains |
| Scrolls | Candidate low-tier spells: Candlelight, Oakflesh, Firebolt, Ice Spike, Lightning Bolt | Only records actually present in vanilla; no high-tier summon/destruction windfalls |
| Soul gems | Petty, lesser, common; greater/grand only at sufficient wealth/budget | Empty weighted more heavily than filled; no black soul gems by default |
| Lockpicks | Standard vanilla lockpick | Small stack; occupation affects chance |

## Occupations and sorting

The labels below describe intended vanilla faction/class mappings. They are not a verified EditorID/FormID registry. Implementation must extract actual NPC, faction, class, vendor, and template records from the installed masters; do not guess record identifiers or classify by display-name substring.

Proposed wealth roll percentages within each occupation:

| Occupation | Wealth selection | Primary classification evidence | Favored contents |
|---|---|---|---|
| Beggar | Destitute 85%, Poor 15% | Beggar role/faction/class | Food |
| Farmer / laborer | Poor 60%, Common 40% | Farmer/laborer class or verified work role | Food, ingredients |
| Miner / smith | Poor 20%, Common 50%, Comfortable 30% | Miner/blacksmith class or smith vendor role | Gems, food |
| Guard / soldier | Common 80%, Comfortable 20% | Genuine guard status; Imperial/Stormcloak soldier roles | Food, potions |
| Hunter / fisherman | Poor 40%, Common 60% | Hunter/fisherman class or verified work role | Food, ingredients |
| Innkeeper | Comfortable 80%, Wealthy 20% | Innkeeper class and inn vendor/service role | Food/drink, coins |
| Merchant | Comfortable 60%, Wealthy 40% | Actual vendor faction/service, excluding specialized roles above | Jewelry, gems, coins |
| Priest | Common 70%, Comfortable 30% | Priest class or verified temple duties | Jewelry, potions |
| Mage / scholar | Common 40%, Comfortable 45%, Wealthy 15% | Mage/scholar class or verified magical duties | Soul gems, scrolls, ingredients |
| Thief / smuggler | Common 50%, Comfortable 40%, Wealthy 10% | Thief role, actual fence/smuggler service | Jewelry, gems, lockpicks |
| Bandit / outlaw | Poor 50%, Common 40%, Comfortable 10% | Bandit role/faction; verified hostile outlaw roles | Lockpicks, food, jewelry |
| Noble / court official | Wealthy 60%, Noble 40% | Jarl/noble/steward/court official role | Jewelry, gems, coins |
| Adventurer | Common 50%, Comfortable 40%, Wealthy 10% | Verified mercenary/adventurer/Companions-type role; otherwise generic combat class after more specific matches | Potions, food, magical supplies when mage-oriented |
| Fallback | Poor 35%, Common 50%, Comfortable 15% | No reliable specific role match | No preference |
| Child | Separate child table | Child race/actor classification | Restricted child pool |
| Prisoner | Separate prisoner table | Actual prisoner status/role, not generic faction hostility | Restricted prisoner pool |

Occupational category weights: proposed 2x for favored categories, 1x otherwise; cap final category chance at 95%. Coin-favored roles bias the existing gold range toward its higher portion without raising the ceiling. Magical allegiance alone does not make every member a wealthy mage. Criminal allegiance alone does not make a merchant a bandit.

Classification order:

1. Exclude player, non-playable/non-human races, summons, dead actors, and active followers from generation.
2. Explicit verified per-NPC role overrides where needed.
3. Prisoner status, then child table. Proposed: an imprisoned child uses the more restrictive prisoner table, retaining child safety restrictions.
4. Guard/soldier, noble/court official, beggar, innkeeper, miner/smith, hunter/fisherman, farmer/laborer, priest, thief/smuggler, merchant, bandit/outlaw, mage/scholar, adventurer, fallback.
5. Strong explicit occupation evidence wins over generic combat class evidence. A court mage maps to mage with a court wealth override; a bandit mage maps to bandit with magical item preferences. A guard with a merchant-like class remains a guard.
6. General guild membership does not override a specific job. Combat classes are the final role hint, not proof of occupation.
7. Hostility to the player is not a loot profile. Hostile NPCs retain their occupation; unmatched hostile playable-race NPCs use fallback. Forsworn/other outlaw mappings require record inspection before inclusion.
8. Save wealth and role selection for the generation cycle. Location and faction changes do not cause immediate rerolls or refills.

Confirmed humanlike scope: the ten playable races, including Khajiit and Argonians, plus verified vampire variants; excludes animals, creatures, undead creature races, Dremora, and summons.

## Followers

Eligible only while not actively following the player. Being a potential follower is not itself an exclusion. Recruiting or dismissing preserves generation state and does not reroll loot. NPCs first seen as active followers wait until eligible for first initialization.

## Deferred ammunition feature

Arrow generation, replenishment, caps, timers, and player-gift tracking have been removed from this mod. The former proposal is preserved in `deferred-arrow-mod.md` for a separate mod.

## Plugin slots and SPID assessment

The DLL uses no plugin slot, so no ESL flag is necessary. There is no companion ESP/ESM to flag. SPID would not replace inventory-aware shortfall calculations or per-reference saved reset cycles. Adding a dependency to repeat the existing one-time classification/distribution work is not a demonstrated optimization, so it is not introduced. SPID-distributed existing possessions still participate in recognized inventory accounting.

## Resets and persistence

- Detect actual inventory reset completion, clear affected generation state, and scan the resulting inventory before any additions. A reset during active following records a pending cycle without distributing until eligible.
- An empty inventory is not proof of reset. Resurrection without inventory reset is not a fresh cycle. Reset code must be protected against duplicate/reentrant notifications.
- Pocket loot re-evaluates after an actual inventory reset.
- Save per-reference state, including completed/pending generation, reset cycle, wealth roll, role, and random state.
- Schema migration on update preserves existing completion flags and random state; no distribution rerun solely for new version or changed defaults.
- Persist state with the save using SKSE serialization and versioned migrations. Keep state tied to the loaded save, including older or branched saves, rather than using a global external ledger.
- Uninstall/reinstall persistence is not required. No external reinstall ledger is needed. Updates must retain loot generation flags, profiles, and random state, including pending legitimate inventory resets.

## Remaining work before implementation

1. Translate the approved balance and eligibility rules into concrete generation algorithms, including coins-only rolls and the final pocket-possession guarantee.
2. Inspect actual master records to build a verified faction/class/NPC override registry and item form lists.
3. Establish exact supported SE/AE runtimes and dependencies, verify all required hooks on each.
4. Prove reset detection, save/update migration behavior before promising those behaviors.
5. Implement and test in game: existing-item shortfalls including worn jewelry, coin fallback, theft/no refill, load/save, genuine resets, active follower transitions, hostile NPCs, and updates with older/branched saves.

Schema 2 removes ammunition metadata. The schema-1 reader validates and discards historical ammunition fields while preserving the actor's loot completion flag, profile, RNG state, and reset cycle.


## Current supplement � victim timers and editable pools

The current 1.0.0 build includes the editable item-pool INI previously previewed as 1.1.0. The user additionally approved a three-game-day pickpocket-victim cooldown. This explicitly supersedes the earlier genuine-reset-only regeneration rule: a successful theft starts one non-extending countdown, whose expiry permits one shortfall-only loot roll without resetting vanilla inventory. A new theft is required to arm another countdown. Genuine inventory resets still supersede/cancel the timer and permit a normal cycle. Followers defer generation while retaining deadlines. Schema 3 persists deadlines and migrates schemas 1/2 without retroactive timers or rerolls. See README.md, LOOT-POOLS.md, and research/v1.0.0-victim-timer.md for current behavior and limitations.
