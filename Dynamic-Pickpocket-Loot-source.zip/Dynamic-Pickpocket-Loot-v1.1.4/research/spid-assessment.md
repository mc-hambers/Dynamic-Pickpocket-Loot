# SPID integration assessment — v0.1.1

User requested SPID integration where it would optimize this mod, and light-plugin support if applicable.

Decision: retain the slot-free SKSE DLL. Do not add an ESP/ESL, dummy marker plugin, or SPID dependency without a demonstrated benefit for the remaining feature set.

The [official SPID reference](https://github.com/powerof3/Spell-Perk-Item-Distributor/blob/master/resources/SPID%20Complete%20Reference.txt) documents lazy distribution, ordinary item counts, and dynamically created keywords. A companion ESP is not inherently required to use SPID; it is also not needed for Pickpocketing Loot.

Pickpocketing Loot must inspect the current reference inventory, subtract existing possessions, enforce shared budgets, preserve per-reference generation state, and detect actual resets. Ordinary SPID item rules do not replace those operations. Native classification runs only when a reference genuinely needs generation, after the saved completion check. Dynamically distributed base keywords could provide classification hints, but would introduce another matching pass and require validation against live role/faction changes. No measured benefit has been established, so this revision does not introduce that bridge or claim an SPID speedup.

SPID-distributed items remain compatible with recognized current-inventory accounting. Distribution order and runtime coexistence still require in-game testing. The mod does not edit or ship changes to SPID itself.
