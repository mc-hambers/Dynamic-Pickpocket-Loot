# Verified vanilla mapping registry

Extracted read-only from installed Skyrim.esm. This is factual identifier data, not copied game assets.

## Occupation mappings

| Record | FormID | Role | Priority |
|---|---|---|---|
| dunPrisonerFaction (Faction) | 000AA784 | Prisoner | 0 |
| TownCidhnaMinePrisonerFaction (Faction) | 000284AE | Prisoner | 0 |
| MS09NorthwatchPrisonerFaction (Faction) | 000C1AA5 | Prisoner | 0 |
| dunFellglow_PrisonerFaction (Faction) | 0007E7A3 | Prisoner | 0 |
| SolitudeOpeningPrisonerFaction (Faction) | 0010FD8E | Prisoner | 0 |
| Prisoner (Class) | 00013263 | Prisoner | 0 |
| JobJarlFaction (Faction) | 00050920 | Noble | 20 |
| JobStewardFaction (Faction) | 00050922 | Noble | 20 |
| WERoad02NobleFaction (Faction) | 00102D60 | Noble | 20 |
| JobOrcChiefFaction (Faction) | 0005159B | Noble | 20 |
| FavorJobsBeggarsFaction (Faction) | 00060028 | Beggar | 30 |
| Beggar (Class) | 0001327B | Beggar | 30 |
| JobInnkeeperFaction (Faction) | 0005091B | Innkeeper | 40 |
| JobRentRoomFaction (Faction) | 0009CC97 | Innkeeper | 40 |
| JobBlacksmithFaction (Faction) | 0005091D | Smith | 50 |
| JobMinerFaction (Faction) | 00051597 | Smith | 50 |
| VendorBlacksmith (Class) | 00013257 | Smith | 50 |
| Miner (Class) | 0001326D | Smith | 50 |
| HunterFaction (Faction) | 0004E509 | Hunter | 60 |
| FishermanFaction (Faction) | 00073FC3 | Hunter | 60 |
| WEServicesHunterFaction (Faction) | 000AC9C2 | Hunter | 60 |
| JobFarmerFaction (Faction) | 00051591 | Farmer | 70 |
| JobLumberjackFaction (Faction) | 00051595 | Farmer | 70 |
| Farmer (Class) | 0001326C | Farmer | 70 |
| Lumberjack (Class) | 0001326E | Farmer | 70 |
| JobPriestFaction (Faction) | 0005159A | Priest | 80 |
| Priest (Class) | 00013276 | Priest | 80 |
| JobFenceFaction (Faction) | 000806AA | Thief | 90 |
| WIThiefFaction (Faction) | 00023EEC | Thief | 90 |
| JobMerchantFaction (Faction) | 00051596 | Merchant | 100 |
| JobJewelerFaction (Faction) | 000806A9 | Merchant | 100 |
| JobTailorFaction (Faction) | 000806A8 | Merchant | 100 |
| JobStreetVendorFaction (Faction) | 0007F6BE | Merchant | 100 |
| JobFletcherFaction (Faction) | 00051592 | Merchant | 100 |
| JobApothecaryFaction (Faction) | 0005091C | Merchant | 100 |
| VendorTailor (Class) | 00013270 | Merchant | 110 |
| VendorPawnbroker (Class) | 0001325B | Merchant | 110 |
| VendorFletcher (Class) | 00013259 | Merchant | 110 |
| VendorApothecary (Class) | 00013258 | Merchant | 110 |
| VendorFood (Class) | 00013256 | Merchant | 110 |
| BanditFaction (Faction) | 0001BCC0 | Bandit | 120 |
| ForswornFaction (Faction) | 00043599 | Bandit | 120 |
| EncClassBanditMelee (Class) | 0001CE17 | Bandit | 125 |
| EncClassBanditMissile (Class) | 00015BE7 | Bandit | 125 |
| EncClassForsworn (Class) | 00043BCB | Bandit | 125 |
| EncClassForswornMissile (Class) | 00043BCD | Bandit | 125 |
| EncClassBanditWizard (Class) | 00039D30 | Bandit | 125 |
| EncClassForswornShaman (Class) | 00043BCC | Bandit | 125 |
| JobCourtWizardFaction (Faction) | 0005091E | Mage | 15 |
| JobSpellFaction (Faction) | 00050921 | Mage | 130 |
| WarlockFaction (Faction) | 00026724 | Mage | 130 |
| VendorSpells (Class) | 0001325A | Mage | 130 |
| CompanionsFaction (Faction) | 00048362 | Adventurer | 150 |
| WEUnaggressiveAdventurerFaction (Faction) | 00105D14 | Adventurer | 150 |
| WEAggressiveAdventurerFaction (Faction) | 00105D13 | Adventurer | 150 |
| WEBountyHunter (Faction) | 000BC09E | Adventurer | 150 |
| dunIronbindAdventurerFaction (Faction) | 0006CD5D | Adventurer | 150 |
| ThievesGuildFaction (Faction) | 00029DA9 | Thief | 190 |
| CollegeofWinterholdFaction (Faction) | 0001F259 | Mage | 190 |
| DarkBrotherhoodFaction (Faction) | 0001BDB3 | Adventurer | 190 |
| GuardImperial (Class) | 000253F2 | Guard | 10 |
| GuardSonsSkyrim (Class) | 000253F3 | Guard | 10 |
| GuardOrc1H (Class) | 0002A477 | Guard | 10 |
| GuardOrc2H (Class) | 0010E714 | Guard | 10 |
| SoldierImperialNotGuard (Class) | 0001327F | Guard | 10 |
| SoldierSonsSkyrimNotGuard (Class) | 00013280 | Guard | 10 |
| CWSoldierClass (Class) | 0010B1D8 | Guard | 10 |
| Jailor (Class) | 0001325E | Guard | 10 |
| NPCclassBelrand (Class) | 0010F7F9 | Adventurer | 210 |
| CombatNightingale (Class) | 000FB0DA | Adventurer | 210 |
| TrainerRestorationJourneyman (Class) | 000C2914 | Mage | 200 |
| TrainerIllusionExpert (Class) | 000B812C | Mage | 200 |
| TrainerIllusionMaster (Class) | 00042DC6 | Mage | 200 |
| TrainerConjurationExpert (Class) | 000E3A78 | Mage | 200 |
| TrainerEnchantingMaster (Class) | 000E3A77 | Mage | 200 |
| TrainerEnchantingExpert (Class) | 000E3A76 | Mage | 200 |
| TrainerRestorationMaster (Class) | 000E3A75 | Mage | 200 |
| TrainerRestorationExpert (Class) | 000E3A74 | Mage | 200 |
| TrainerDestructionMaster (Class) | 000E3A73 | Mage | 200 |
| TrainerConjurationJourneyman (Class) | 000E3A72 | Mage | 200 |
| TrainerAlterationExpert (Class) | 000E3A71 | Mage | 200 |
| TrainerConjurationMaster (Class) | 000E3A6A | Mage | 200 |
| TrainerAlterationMaster (Class) | 000E3A69 | Mage | 200 |
| TrainerDestructionExpert (Class) | 000E3A5C | Mage | 200 |
| TrainerDestructionJourneyman (Class) | 000E2FCD | Mage | 200 |
| CombatMageNecro (Class) | 000C969F | Mage | 200 |
| EncClassPenitusOculatus (Class) | 0007D98D | Adventurer | 210 |
| EncClassThalmorMelee (Class) | 0007289D | Adventurer | 210 |
| EncClassThalmorMissile (Class) | 00072891 | Adventurer | 210 |
| EncClassAlikrMissile (Class) | 0006766C | Adventurer | 210 |
| EncClassAlikrMelee (Class) | 0006766B | Adventurer | 210 |
| CombatMageDestruction (Class) | 0001E7D0 | Mage | 200 |
| CombatBarbarian (Class) | 0001CE16 | Adventurer | 210 |
| CombatWarrior2H (Class) | 0001CE15 | Adventurer | 210 |
| CombatMageConjurer (Class) | 0001CE14 | Mage | 200 |
| CombatMonk (Class) | 00013182 | Adventurer | 210 |
| CombatRanger (Class) | 00013181 | Adventurer | 210 |
| CombatRogue (Class) | 00013180 | Adventurer | 210 |
| CombatAssassin (Class) | 0001317F | Adventurer | 210 |
| CombatThief (Class) | 0001317E | Adventurer | 210 |
| CombatScout (Class) | 0001317D | Adventurer | 210 |
| CombatNightblade (Class) | 0001317C | Mage | 200 |
| CombatMystic (Class) | 0001317B | Mage | 200 |
| CombatMageElemental (Class) | 0001317A | Mage | 200 |
| CombatSorcerer (Class) | 00013179 | Mage | 200 |
| CombatWitchblade (Class) | 00013178 | Mage | 200 |
| CombatSpellsword (Class) | 00013177 | Mage | 200 |
| CombatWarrior1H (Class) | 00013176 | Adventurer | 210 |

## Item pool

| Record | FormID | Category | Minimum wealth |
|---|---|---|---|
| FoodBread01A | 00065C97 | Food | Destitute |
| FoodBread01B | 00065C98 | Food | Destitute |
| FoodApple | 00064B2E | Food | Destitute |
| FoodApple02 | 00064B2F | Food | Destitute |
| FoodCarrot | 00064B40 | Food | Destitute |
| FoodPotato | 00064B41 | Food | Destitute |
| FoodCheeseWedge01 | 00064B31 | Food | Destitute |
| FoodCheeseWedge02 | 00064B32 | Food | Destitute |
| FoodBeefCooked | 000721E8 | Food | Destitute |
| FoodVenisonCooked | 000722BD | Food | Destitute |
| FoodSalmonCooked | 00064B3B | Food | Destitute |
| Ale | 00034C5E | Food | Destitute |
| FoodMead | 00034C5D | Food | Destitute |
| FoodWineBottle02 | 0003133C | Food | Destitute |
| FoodWineAlto | 0003133B | Food | Destitute |
| FoodHonningbrewMead | 000508CA | Food | Destitute |
| FoodBlackBriarMead | 0002C35A | Food | Destitute |
| FoodSolitudeSpicedWine | 00085368 | Food | Comfortable |
| FoodBlackBriarMeadPrivateReserve | 000F693F | Food | Comfortable |
| JewelryNecklaceSilver | 0009171B | Jewelry | Destitute |
| JewelryNecklaceGoldGems | 00087835 | Jewelry | Destitute |
| JewelryNecklaceSilverGems | 00087834 | Jewelry | Destitute |
| JewelryNecklaceSilverEmerald | 00087833 | Jewelry | Destitute |
| JewelryNecklaceSilverSapphire | 00087832 | Jewelry | Destitute |
| JewelryNecklaceGoldDiamond | 000877F1 | Jewelry | Destitute |
| JewelryNecklaceGoldRuby | 000877DC | Jewelry | Destitute |
| JewelryNecklaceGold | 000877D5 | Jewelry | Destitute |
| JewelryRingGoldSapphire | 000877CB | Jewelry | Destitute |
| JewelryRingGoldEmerald | 000877CA | Jewelry | Destitute |
| JewelryRingGoldDiamond | 000877C9 | Jewelry | Destitute |
| JewelryRingSilverRuby | 000877B1 | Jewelry | Destitute |
| JewelryRingSilverGarnet | 000877AB | Jewelry | Destitute |
| JewelryRingSilverAmethyst | 000877A7 | Jewelry | Destitute |
| JewelryRingSilver | 0003B97C | Jewelry | Destitute |
| JewelryRingGold | 0001CF2B | Jewelry | Destitute |
| GemSapphireFlawless | 00068523 | Gem | Destitute |
| gemRubyFlawless | 00068522 | Gem | Destitute |
| GemGarnetFlawless | 00068521 | Gem | Destitute |
| GemEmeraldFlawless | 00068520 | Gem | Destitute |
| GemDiamondFlawless | 0006851F | Gem | Destitute |
| GemAmethystFlawless | 0006851E | Gem | Destitute |
| GemDiamond | 00063B47 | Gem | Destitute |
| GemAmethyst | 00063B46 | Gem | Destitute |
| GemGarnet | 00063B45 | Gem | Destitute |
| GemSapphire | 00063B44 | Gem | Destitute |
| GemEmerald | 00063B43 | Gem | Destitute |
| GemRuby | 00063B42 | Gem | Destitute |
| RestoreHealth01 | 0003EADD | Potion | Destitute |
| RestoreMagicka01 | 0003EAE0 | Potion | Destitute |
| RestoreStamina01 | 0003EAE5 | Potion | Destitute |
| RestoreHealth02 | 0003EADE | Potion | Poor |
| RestoreMagicka02 | 0003EAE1 | Potion | Poor |
| RestoreStamina02 | 00039BE8 | Potion | Poor |
| RestoreHealth03 | 0003EADF | Potion | Common |
| RestoreMagicka03 | 0003EAE2 | Potion | Common |
| RestoreStamina03 | 0003EAE7 | Potion | Common |
| RestoreHealth04 | 0003EAE3 | Potion | Comfortable |
| RestoreMagicka04 | 0003EAE4 | Potion | Comfortable |
| RestoreStamina04 | 0003EAE8 | Potion | Comfortable |
| MountainFlower01Blue | 00077E1C | Ingredient | Destitute |
| MountainFlower01Red | 00077E1D | Ingredient | Destitute |
| MountainFlower01Purple | 00077E1E | Ingredient | Destitute |
| Lavender | 00045C28 | Ingredient | Destitute |
| TundraCotton | 0003F7F8 | Ingredient | Destitute |
| Thistle01 | 000134AA | Ingredient | Destitute |
| SaltPile | 00034CDF | Ingredient | Destitute |
| Garlic | 00034D22 | Ingredient | Destitute |
| Snowberry | 0001B3BD | Ingredient | Destitute |
| FrostMirriam | 00034D32 | Ingredient | Destitute |
| ElvesEar | 00034D31 | Ingredient | Destitute |
| BoneMeal | 00034CDD | Ingredient | Destitute |
| CandlelightScroll | 0009659B | Magic | Destitute |
| OakfleshScroll | 0009659C | Magic | Destitute |
| FireboltScroll | 00096598 | Magic | Destitute |
| IceSpikeScroll | 00096599 | Magic | Destitute |
| LightningBoltScroll | 0009659A | Magic | Destitute |
| SoulGemGrandFilled | 0002E4FF | Magic | Wealthy |
| SoulGemGrand | 0002E4FC | Magic | Wealthy |
| SoulGemGreaterFilled | 0002E4FB | Magic | Wealthy |
| SoulGemGreater | 0002E4F4 | Magic | Wealthy |
| SoulGemCommonFilled | 0002E4F3 | Magic | Common |
| SoulGemCommon | 0002E4E6 | Magic | Common |
| SoulGemLesserFilled | 0002E4E5 | Magic | Destitute |
| SoulGemLesser | 0002E4E4 | Magic | Destitute |
| SoulGemPettyFilled | 0002E4E3 | Magic | Destitute |
| SoulGemPetty | 0002E4E2 | Magic | Destitute |
| Lockpick | 0000000A | Lockpick | Destitute |

## Eligible race forms

- ArgonianRace: 00013740
- ArgonianRaceVampire: 0008883A
- BretonRace: 00013741
- BretonRaceChild: 0002C65C
- BretonRaceChildVampire: 00108272
- BretonRaceVampire: 0008883C
- DarkElfRace: 00013742
- DarkElfRaceVampire: 0008883D
- ElderRace: 00067CD8
- ElderRaceVampire: 000A82BA
- HighElfRace: 00013743
- HighElfRaceVampire: 00088840
- ImperialRace: 00013744
- ImperialRaceChild: 0002C659
- ImperialRaceVampire: 00088844
- KhajiitRace: 00013745
- KhajiitRaceVampire: 00088845
- NordRace: 00013746
- NordRaceChild: 0002C65B
- NordRaceVampire: 00088794
- OrcRace: 00013747
- OrcRaceVampire: 000A82B9
- RedguardRace: 00013748
- RedguardRaceChild: 0002C65A
- RedguardRaceVampire: 00088846
- WoodElfRace: 00013749
- WoodElfRaceVampire: 00088884
