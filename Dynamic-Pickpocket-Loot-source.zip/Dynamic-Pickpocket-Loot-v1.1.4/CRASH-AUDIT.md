# Restoration crash audit — 1.1.3

## Confirmed defect

The combined SE/AE CommonLib ExtraDataList type in this checkout is a runtime-accessor facade, not a correctly sized allocation type. The previous restoration code called `new RE::ExtraDataList()`. Disassembly of the compiled 1.1.2 object shows that call requesting **0x0C / 12 bytes**.

The installed Skyrim 1.7.104 executable's actual constructor, mapped through Address Library ID 11583 to RVA 0x157420, stores a vtable pointer at offset 0, a pointer at offset 8, a pointer at offset 16, and constructs its lock at offset 24. The supported modern AE layout needs **0x20 / 32 bytes**. The pointer store at offset 16 alone is already outside the previous allocation.

That is a concrete heap-buffer overrun during creation of temporary clothing instance data. It can corrupt adjacent allocations and fail later during equipping, another restoration, save/load, or unrelated engine work. Queuing equipment or waiting for a reload does not repair the undersized allocation.

## Correction

`RuntimeExtraData.h` reserves at least 32 bytes from Skyrim's own heap and placement-constructs the game-backed object in that storage. A larger future facade size is also respected. No shared class layout is enlarged, because doing so could shift layouts of engine classes that embed the facade. The existing runtime field accessors and native constructor remain in use.

The restoration path no longer uses a direct `new RE::ExtraDataList()`. Body/eligible-feet restrictions and saved timers remain. The 1.1.1 scheduling and 1.1.2 travel/reload requirements have been removed in subsequent releases. Logs now distinguish allocation, inventory-add, and equipment entry/return stages.

## Equip-function inspection

The installed Address Library maps EquipObject ID 38894 to executable RVA 0x6DC310. Its entry checks the actor/object arguments in the expected argument registers and handles an optional extra-data argument. The singleton and other equipment helpers are checked separately. This audit did not identify a wrong mapping for EquipObject; executable-address checks alone cannot prove every runtime ABI or every third-party hook is correct.

The item addition itself uses the same actor inventory API that existing pocket-loot distribution uses. Temporary clothing differs because it supplies the newly allocated extra-data list, making the allocation overrun a direct suspect specific to this feature.

## Evidence and limits

- Local research contains the pre-fix compiled allocation disassembly and read-only game constructor/equipment disassembly. Game code dumps are not distributed in the release archives.
- Regression tests simulate a 32-byte native constructor operating on a 12-byte C++ facade and verify sufficient reserved capacity and an untouched boundary guard. Allocation failure and 24-/32-/larger-byte facade cases are covered.
- Binary validation audits the installed constructor's relevant writes and equipment-related relocation targets.
- The original 1.1.0 log ended after restoring a guard's tunic and boots. Later inspected logs ended earlier and supplied no crash stack. The overrun is confirmed in the pre-fix binary; it is not established as the only possible crash cause.
- Test 1.1.3 from a save made before the restoration crashes, using the same timescale and theft/travel sequence. The fix has not been tested in Skyrim here. Previously damaged saved inventory data, other hooks, equipment meshes, and other runtime issues require a crash stack if failures continue.
