Copyright (C) 2026 Maxmc

This mod's original code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <https://www.gnu.org/licenses/>.

Full license: LICENSE.txt
Corresponding source, dependency sources, build scripts, and original notices are hosted on GitHub:
https://github.com/mc-hambers/Dynamic-Pickpocket-Loot/tree/source-1.2.0

Third-party components retain their original copyrights and licenses.
CommonLibSSE-NG permissions and exceptions are preserved in the source archive
and reproduced under Third-Party-Licenses. This notice does not relicense any
third-party material. Build tools and game dependencies must be obtained
separately where the included build instructions require them.

This runtime archive contains game files and licensing notices. Full corresponding
source and build files are available at the versioned GitHub link above.
Legal notices do not need to be installed into the game Data folder.
Nexus page permissions must separately allow modification and redistribution
under the license terms. This tool does not change the Nexus page.
