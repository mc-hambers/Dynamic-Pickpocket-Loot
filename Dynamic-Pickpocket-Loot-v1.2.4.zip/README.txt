Dynamic Pickpocket Loot 1.2.4

MISSING CONFIG FIX
The older runtime archive intentionally shipped only the DLL, leaving the editable loot-pool INI absent on installations without a separate config. This build embeds the complete default pool file and creates Data/SKSE/Plugins/DynamicPickpocketLoot.ini at startup only when missing. The default file is written to an exclusive temporary file and atomically published without replacing an existing target. Existing custom, empty, malformed or read-only configs are preserved. Concurrent creation cannot replace somebody else's completed config. The jewelry Settings INI is unchanged.

The recreated pool entries, order, wealth thresholds and child/prisoner safety flags exactly match the existing built-in vanilla pools. This does not reset generated NPCs or reroll existing save history. If creation fails or an existing file cannot be read, the original built-in fallback remains and the warning now includes the exact path/error. A readable intentionally empty config still means coins only.

INSTALL
Close Skyrim. Update the existing Dynamic Pickpocket Loot mod in Vortex, retain any existing pool/settings INIs, deploy and restart Skyrim. The DLL creates the missing editable pool INI on the next startup; it is deliberately not overlaid by this archive, so Vortex does not replace custom pool settings during the update. Native filename remains PickpocketingLoot.dll. No new save, save cleaner or Nemesis generation is needed.

SAVE COMPATIBILITY / VALIDATION
Original save/load/revert functions, serialization ID, schema 4, actor/item records and exported cycle API remain unchanged. Native build, 65806 behavior/serialization checks, and 104 file-creation/default-pool checks passed, including custom/empty/read-only preservation and concurrent creators. Actual first-start creation and loot generation on your next game session still need log/gameplay verification. Look for "Created missing editable loot config" followed by "Loading loot pools from".
