Copyright (C) 2026 Maxmc.
Original code is GPL-3.0-or-later. See LICENSE.txt for terms and warranty disclaimer.
Matching complete source archive: Dynamic-Pickpocket-Loot-v1.2.3-source.zip
Source release: https://github.com/mc-hambers/Dynamic-Pickpocket-Loot/releases/tag/v1.2.3
